package it.cgmconsulting.myblog.entity.common;

public enum ReportingStatus {

    OPEN,IN_PROGRESS,CLOSED_WITH_BAN,CLOSED_WITHOUT_BAN
}
